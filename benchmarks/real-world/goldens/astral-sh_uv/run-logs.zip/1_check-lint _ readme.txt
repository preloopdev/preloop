﻿2026-08-01T02:36:47.2335951Z Current runner version: '2.336.0'
2026-08-01T02:36:47.2364154Z ##[group]Runner Image Provisioner
2026-08-01T02:36:47.2365090Z Hosted Compute Agent
2026-08-01T02:36:47.2365661Z Version: 20260624.560
2026-08-01T02:36:47.2366656Z Commit: 925d229a51159bc391ae97e54a2dd1fe20af789d
2026-08-01T02:36:47.2367468Z Build Date: 2026-06-24T18:26:47Z
2026-08-01T02:36:47.2368122Z Worker ID: {80b4c543-ba0f-4686-a064-20ae2a83361f}
2026-08-01T02:36:47.2368810Z Azure Region: eastus
2026-08-01T02:36:47.2369356Z ##[endgroup]
2026-08-01T02:36:47.2370825Z ##[group]VM Image
2026-08-01T02:36:47.2371489Z - OS: Linux (x64)
2026-08-01T02:36:47.2372052Z - Source: Docker
2026-08-01T02:36:47.2372567Z - Name: ubuntu:24.04
2026-08-01T02:36:47.2373168Z - Version: 20260629.59.1
2026-08-01T02:36:47.2373720Z ##[endgroup]
2026-08-01T02:36:47.2374697Z ##[group]GITHUB_TOKEN Permissions
2026-08-01T02:36:47.2377002Z Metadata: read
2026-08-01T02:36:47.2377664Z ##[endgroup]
2026-08-01T02:36:47.2380087Z Secret source: None
2026-08-01T02:36:47.2381364Z Prepare workflow directory
2026-08-01T02:36:47.2903202Z Prepare all required actions
2026-08-01T02:36:47.2962095Z Getting action download info
2026-08-01T02:36:47.6293140Z Download action repository 'actions/checkout@9c091bb21b7c1c1d1991bb908d89e4e9dddfe3e0' (SHA:9c091bb21b7c1c1d1991bb908d89e4e9dddfe3e0)
2026-08-01T02:36:47.7500372Z Download action repository 'actions/setup-python@ece7cb06caefa5fff74198d8649806c4678c61a1' (SHA:ece7cb06caefa5fff74198d8649806c4678c61a1)
2026-08-01T02:36:48.1092443Z Uses: astral-sh/uv/.github/workflows/check-lint.yml@refs/pull/20876/merge (81742a27ad62bb1dd1289a164f1776508279c756)
2026-08-01T02:36:48.1097835Z ##[group] Inputs
2026-08-01T02:36:48.1098412Z   code-changed: false
2026-08-01T02:36:48.1098926Z   save-rust-cache: false
2026-08-01T02:36:48.1099435Z ##[endgroup]
2026-08-01T02:36:48.1099898Z Complete job name: check-lint / readme
2026-08-01T02:36:48.1879967Z ##[group]Run actions/checkout@9c091bb21b7c1c1d1991bb908d89e4e9dddfe3e0
2026-08-01T02:36:48.1881117Z with:
2026-08-01T02:36:48.1881617Z   persist-credentials: false
2026-08-01T02:36:48.1882151Z   repository: astral-sh/uv
2026-08-01T02:36:48.1886554Z   token: ***
2026-08-01T02:36:48.1887108Z   ssh-strict: true
2026-08-01T02:36:48.1887563Z   ssh-user: git
2026-08-01T02:36:48.1887992Z   clean: true
2026-08-01T02:36:48.1888443Z   sparse-checkout-cone-mode: true
2026-08-01T02:36:48.1888965Z   fetch-depth: 1
2026-08-01T02:36:48.1889396Z   fetch-tags: false
2026-08-01T02:36:48.1889847Z   show-progress: true
2026-08-01T02:36:48.1890308Z   lfs: false
2026-08-01T02:36:48.1890728Z   submodules: false
2026-08-01T02:36:48.1891182Z   set-safe-directory: true
2026-08-01T02:36:48.1891692Z   allow-unsafe-pr-checkout: false
2026-08-01T02:36:48.1892505Z env:
2026-08-01T02:36:48.1892923Z   CARGO_INCREMENTAL: 0
2026-08-01T02:36:48.1893382Z   CARGO_NET_RETRY: 10
2026-08-01T02:36:48.1893893Z   CARGO_TERM_COLOR: always
2026-08-01T02:36:48.1894364Z   HAWK_VERSION: 0.1.9
2026-08-01T02:36:48.1894828Z   RUSTUP_MAX_RETRIES: 10
2026-08-01T02:36:48.1895303Z ##[endgroup]
2026-08-01T02:36:48.3486046Z Syncing repository: astral-sh/uv
2026-08-01T02:36:48.3488589Z ##[group]Getting Git version info
2026-08-01T02:36:48.3489303Z Working directory is '/home/runner/work/uv/uv'
2026-08-01T02:36:48.3490258Z [command]/usr/bin/git version
2026-08-01T02:36:48.3786074Z git version 2.54.0
2026-08-01T02:36:48.3790129Z ##[endgroup]
2026-08-01T02:36:48.3795772Z Temporarily overriding HOME='/home/runner/work/_temp/c20f4535-a189-4973-987f-29a2e5dabd07' before making global git config changes
2026-08-01T02:36:48.3797480Z Adding repository directory to the temporary git global config as a safe directory
2026-08-01T02:36:48.3798516Z [command]/usr/bin/git config --global --add safe.directory /home/runner/work/uv/uv
2026-08-01T02:36:48.3934611Z Deleting the contents of '/home/runner/work/uv/uv'
2026-08-01T02:36:48.3935873Z ##[group]Determining repository object format
2026-08-01T02:36:48.3937124Z ##[endgroup]
2026-08-01T02:36:48.3937867Z ##[group]Initializing the repository
2026-08-01T02:36:48.3940075Z [command]/usr/bin/git init /home/runner/work/uv/uv
2026-08-01T02:36:48.5280939Z hint: Using 'master' as the name for the initial branch. This default branch name
2026-08-01T02:36:48.5282206Z hint: will change to "main" in Git 3.0. To configure the initial branch name
2026-08-01T02:36:48.5283581Z hint: to use in all of your new repositories, which will suppress this warning,
2026-08-01T02:36:48.5284347Z hint: call:
2026-08-01T02:36:48.5284749Z hint:
2026-08-01T02:36:48.5285264Z hint: 	git config --global init.defaultBranch <name>
2026-08-01T02:36:48.5285868Z hint:
2026-08-01T02:36:48.5286775Z hint: Names commonly chosen instead of 'master' are 'main', 'trunk' and
2026-08-01T02:36:48.5287724Z hint: 'development'. The just-created branch can be renamed via this command:
2026-08-01T02:36:48.5288458Z hint:
2026-08-01T02:36:48.5288948Z hint: 	git branch -m <name>
2026-08-01T02:36:48.5289416Z hint:
2026-08-01T02:36:48.5290033Z hint: Disable this message with "git config set advice.defaultBranchName false"
2026-08-01T02:36:48.5290963Z Initialized empty Git repository in /home/runner/work/uv/uv/.git/
2026-08-01T02:36:48.5292670Z [command]/usr/bin/git remote add origin https://github.com/astral-sh/uv
2026-08-01T02:36:48.5294205Z ##[endgroup]
2026-08-01T02:36:48.5294947Z ##[group]Disabling automatic garbage collection
2026-08-01T02:36:48.5295589Z [command]/usr/bin/git config --local gc.auto 0
2026-08-01T02:36:48.5297218Z ##[endgroup]
2026-08-01T02:36:48.5298241Z ##[group]Setting up auth
2026-08-01T02:36:48.5298748Z Removing SSH command configuration
2026-08-01T02:36:48.5299499Z [command]/usr/bin/git config --local --name-only --get-regexp core\.sshCommand
2026-08-01T02:36:48.5301518Z [command]/usr/bin/git submodule foreach --recursive sh -c "git config --local --name-only --get-regexp 'core\.sshCommand' && git config --local --unset-all 'core.sshCommand' || :"
2026-08-01T02:36:48.5710319Z Removing HTTP extra header
2026-08-01T02:36:48.5711339Z [command]/usr/bin/git config --local --name-only --get-regexp http\.https\:\/\/github\.com\/\.extraheader
2026-08-01T02:36:50.4595918Z [command]/usr/bin/git submodule foreach --recursive sh -c "git config --local --name-only --get-regexp 'http\.https\:\/\/github\.com\/\.extraheader' && git config --local --unset-all 'http.https://github.com/.extraheader' || :"
2026-08-01T02:36:50.4599282Z Removing includeIf entries pointing to credentials config files
2026-08-01T02:36:50.4600324Z [command]/usr/bin/git config --local --name-only --get-regexp ^includeIf\.gitdir:
2026-08-01T02:36:50.4602315Z [command]/usr/bin/git submodule foreach --recursive git config --local --show-origin --name-only --get-regexp remote.origin.url
2026-08-01T02:36:50.4607280Z [command]/usr/bin/git config --file /home/runner/work/_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config http.https://github.com/.extraheader AUTHORIZATION: basic ***
2026-08-01T02:36:50.4610486Z [command]/usr/bin/git config --local includeIf.gitdir:/home/runner/work/uv/uv/.git.path /home/runner/work/_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config
2026-08-01T02:36:50.4613374Z [command]/usr/bin/git config --local includeIf.gitdir:/home/runner/work/uv/uv/.git/worktrees/*.path /home/runner/work/_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config
2026-08-01T02:36:50.4616310Z [command]/usr/bin/git config --local includeIf.gitdir:/github/workspace/.git.path /github/runner_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config
2026-08-01T02:36:50.4619113Z [command]/usr/bin/git config --local includeIf.gitdir:/github/workspace/.git/worktrees/*.path /github/runner_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config
2026-08-01T02:36:50.4621469Z ##[endgroup]
2026-08-01T02:36:50.4622262Z ##[group]Fetching the repository
2026-08-01T02:36:50.4623723Z [command]/usr/bin/git -c protocol.version=2 fetch --no-tags --prune --no-recurse-submodules --depth=1 origin +81742a27ad62bb1dd1289a164f1776508279c756:refs/remotes/pull/20876/merge
2026-08-01T02:36:56.2360386Z From https://github.com/astral-sh/uv
2026-08-01T02:36:56.2391465Z  * [new ref]         81742a27ad62bb1dd1289a164f1776508279c756 -> pull/20876/merge
2026-08-01T02:36:56.2463110Z ##[endgroup]
2026-08-01T02:36:56.2464367Z ##[group]Determining the checkout info
2026-08-01T02:36:56.2465665Z ##[endgroup]
2026-08-01T02:36:56.2466888Z [command]/usr/bin/git sparse-checkout disable
2026-08-01T02:36:56.2594628Z [command]/usr/bin/git config --local --unset-all extensions.worktreeConfig
2026-08-01T02:36:56.2629679Z ##[group]Checking out the ref
2026-08-01T02:36:56.2637136Z [command]/usr/bin/git checkout --progress --force refs/remotes/pull/20876/merge
2026-08-01T02:36:56.4541841Z Note: switching to 'refs/remotes/pull/20876/merge'.
2026-08-01T02:36:56.4543360Z 
2026-08-01T02:36:56.4545309Z You are in 'detached HEAD' state. You can look around, make experimental
2026-08-01T02:36:56.4552644Z changes and commit them, and you can discard any commits you make in this
2026-08-01T02:36:56.4558346Z state without impacting any branches by switching back to a branch.
2026-08-01T02:36:56.4559816Z 
2026-08-01T02:36:56.4560670Z If you want to create a new branch to retain commits you create, you may
2026-08-01T02:36:56.4567440Z do so (now or later) by using -c with the switch command. Example:
2026-08-01T02:36:56.4568636Z 
2026-08-01T02:36:56.4569157Z   git switch -c <new-branch-name>
2026-08-01T02:36:56.4620808Z 
2026-08-01T02:36:56.4621412Z Or undo this operation with:
2026-08-01T02:36:56.4622298Z 
2026-08-01T02:36:56.4622799Z   git switch -
2026-08-01T02:36:56.4623497Z 
2026-08-01T02:36:56.4624470Z Turn off this advice by setting config variable advice.detachedHead to false
2026-08-01T02:36:56.4625902Z 
2026-08-01T02:36:56.4627825Z HEAD is now at 81742a2 Merge 1ddf5b709ad49bba88e6607af0d2a1bbe0c03ff5 into 79bbface771210df216b738e9bdc7df95e5a9e6b
2026-08-01T02:36:56.4633108Z ##[endgroup]
2026-08-01T02:36:56.4676960Z [command]/usr/bin/git log -1 --format=%H
2026-08-01T02:36:56.4700614Z 81742a27ad62bb1dd1289a164f1776508279c756
2026-08-01T02:36:56.4720760Z ##[group]Removing auth
2026-08-01T02:36:56.4722404Z Removing SSH command configuration
2026-08-01T02:36:56.4732393Z [command]/usr/bin/git config --local --name-only --get-regexp core\.sshCommand
2026-08-01T02:36:56.4780813Z [command]/usr/bin/git submodule foreach --recursive sh -c "git config --local --name-only --get-regexp 'core\.sshCommand' && git config --local --unset-all 'core.sshCommand' || :"
2026-08-01T02:36:56.5072831Z Removing HTTP extra header
2026-08-01T02:36:56.5085371Z [command]/usr/bin/git config --local --name-only --get-regexp http\.https\:\/\/github\.com\/\.extraheader
2026-08-01T02:36:56.5126945Z [command]/usr/bin/git submodule foreach --recursive sh -c "git config --local --name-only --get-regexp 'http\.https\:\/\/github\.com\/\.extraheader' && git config --local --unset-all 'http.https://github.com/.extraheader' || :"
2026-08-01T02:36:56.5332565Z Removing includeIf entries pointing to credentials config files
2026-08-01T02:36:56.5337847Z [command]/usr/bin/git config --local --name-only --get-regexp ^includeIf\.gitdir:
2026-08-01T02:36:56.5362404Z includeif.gitdir:/home/runner/work/uv/uv/.git.path
2026-08-01T02:36:56.5364672Z includeif.gitdir:/home/runner/work/uv/uv/.git/worktrees/*.path
2026-08-01T02:36:56.5367197Z includeif.gitdir:/github/workspace/.git.path
2026-08-01T02:36:56.5369186Z includeif.gitdir:/github/workspace/.git/worktrees/*.path
2026-08-01T02:36:56.5392375Z [command]/usr/bin/git config --local --get-all includeif.gitdir:/home/runner/work/uv/uv/.git.path
2026-08-01T02:36:56.5417187Z /home/runner/work/_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config
2026-08-01T02:36:56.5438322Z [command]/usr/bin/git config --local --unset includeif.gitdir:/home/runner/work/uv/uv/.git.path /home/runner/work/_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config
2026-08-01T02:36:56.5478097Z [command]/usr/bin/git config --local --get-all includeif.gitdir:/home/runner/work/uv/uv/.git/worktrees/*.path
2026-08-01T02:36:56.5502128Z /home/runner/work/_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config
2026-08-01T02:36:56.5522298Z [command]/usr/bin/git config --local --unset includeif.gitdir:/home/runner/work/uv/uv/.git/worktrees/*.path /home/runner/work/_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config
2026-08-01T02:36:56.5562230Z [command]/usr/bin/git config --local --get-all includeif.gitdir:/github/workspace/.git.path
2026-08-01T02:36:56.5584040Z /github/runner_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config
2026-08-01T02:36:56.5604406Z [command]/usr/bin/git config --local --unset includeif.gitdir:/github/workspace/.git.path /github/runner_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config
2026-08-01T02:36:56.5893906Z [command]/usr/bin/git config --local --get-all includeif.gitdir:/github/workspace/.git/worktrees/*.path
2026-08-01T02:36:56.5927852Z /github/runner_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config
2026-08-01T02:36:56.5949459Z [command]/usr/bin/git config --local --unset includeif.gitdir:/github/workspace/.git/worktrees/*.path /github/runner_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config
2026-08-01T02:36:56.6085246Z [command]/usr/bin/git submodule foreach --recursive git config --local --show-origin --name-only --get-regexp remote.origin.url
2026-08-01T02:36:56.6333569Z Removing credentials config '/home/runner/work/_temp/git-credentials-a15bbda4-5296-4a9c-8b53-fbc14181681d.config'
2026-08-01T02:36:56.6347922Z ##[endgroup]
2026-08-01T02:36:56.6755940Z ##[group]Run actions/setup-python@ece7cb06caefa5fff74198d8649806c4678c61a1
2026-08-01T02:36:56.6758051Z with:
2026-08-01T02:36:56.6758928Z   python-version: 3.14
2026-08-01T02:36:56.6759946Z   check-latest: false
2026-08-01T02:36:56.6770345Z   token: ***
2026-08-01T02:36:56.6771271Z   update-environment: true
2026-08-01T02:36:56.6772328Z   allow-prereleases: false
2026-08-01T02:36:56.6773376Z   freethreaded: false
2026-08-01T02:36:56.6774299Z env:
2026-08-01T02:36:56.6775121Z   CARGO_INCREMENTAL: 0
2026-08-01T02:36:56.6776080Z   CARGO_NET_RETRY: 10
2026-08-01T02:36:56.6777308Z   CARGO_TERM_COLOR: always
2026-08-01T02:36:56.6778311Z   HAWK_VERSION: 0.1.9
2026-08-01T02:36:56.6779267Z   RUSTUP_MAX_RETRIES: 10
2026-08-01T02:36:56.6780234Z ##[endgroup]
2026-08-01T02:36:56.8507267Z ##[group]Installed versions
2026-08-01T02:36:56.8587761Z Version 3.14 was not found in the local cache
2026-08-01T02:36:57.3280002Z Version 3.14 is available for downloading
2026-08-01T02:36:57.3284626Z Download from "https://github.com/actions/python-versions/releases/download/3.14.6-27283001424/python-3.14.6-linux-24.04-x64.tar.gz"
2026-08-01T02:36:58.1262753Z Extract downloaded archive
2026-08-01T02:36:58.1399076Z [command]/usr/bin/tar xz --warning=no-unknown-keyword --overwrite -C /home/runner/work/_temp/23b90413-a5d3-44fa-b967-b5d91c523943 -f /home/runner/work/_temp/4b137b08-f283-41bb-9354-160889f2a67d
2026-08-01T02:37:01.6519774Z Execute installation script
2026-08-01T02:37:01.6965515Z Check if Python hostedtoolcache folder exist...
2026-08-01T02:37:01.6982527Z Creating Python hostedtoolcache folder...
2026-08-01T02:37:01.8545436Z Create Python 3.14.6 folder
2026-08-01T02:37:01.8558104Z Copy Python binaries to hostedtoolcache folder
2026-08-01T02:37:03.7557934Z Create additional symlinks (Required for the UsePythonVersion Azure Pipelines task and the setup-python GitHub Action)
2026-08-01T02:37:03.7629435Z Upgrading pip...
2026-08-01T02:37:09.9910966Z Collecting pip
2026-08-01T02:37:10.0567690Z Downloading pip-26.2-py3-none-any.whl.metadata (4.6 kB)
2026-08-01T02:37:10.1468220Z Downloading pip-26.2-py3-none-any.whl (1.8 MB)
2026-08-01T02:37:10.2848037Z ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 1.8/1.8 MB 14.0 MB/s  0:00:00
2026-08-01T02:37:10.2868999Z 
2026-08-01T02:37:10.3271974Z Installing collected packages: pip
2026-08-01T02:37:10.3282615Z Attempting uninstall: pip
2026-08-01T02:37:10.3315777Z Found existing installation: pip 26.1.2
2026-08-01T02:37:10.3683187Z Uninstalling pip-26.1.2:
2026-08-01T02:37:10.3746841Z Successfully uninstalled pip-26.1.2
2026-08-01T02:37:13.8493019Z Successfully installed pip-26.2
2026-08-01T02:37:13.9705449Z Create complete file
2026-08-01T02:37:13.9796684Z Successfully set up CPython (3.14.6)
2026-08-01T02:37:13.9799848Z ##[endgroup]
2026-08-01T02:37:14.0025955Z ##[group]Run python scripts/transform_readme.py --target pypi
2026-08-01T02:37:14.0026879Z [36;1mpython scripts/transform_readme.py --target pypi[0m
2026-08-01T02:37:14.0038862Z shell: /usr/bin/bash -e {0}
2026-08-01T02:37:14.0039130Z env:
2026-08-01T02:37:14.0039337Z   CARGO_INCREMENTAL: 0
2026-08-01T02:37:14.0039561Z   CARGO_NET_RETRY: 10
2026-08-01T02:37:14.0039780Z   CARGO_TERM_COLOR: always
2026-08-01T02:37:14.0042857Z   HAWK_VERSION: 0.1.9
2026-08-01T02:37:14.0043131Z   RUSTUP_MAX_RETRIES: 10
2026-08-01T02:37:14.0043430Z   pythonLocation: /opt/hostedtoolcache/Python/3.14.6/x64
2026-08-01T02:37:14.0043920Z   PKG_CONFIG_PATH: /opt/hostedtoolcache/Python/3.14.6/x64/lib/pkgconfig
2026-08-01T02:37:14.0044350Z   Python_ROOT_DIR: /opt/hostedtoolcache/Python/3.14.6/x64
2026-08-01T02:37:14.0044757Z   Python2_ROOT_DIR: /opt/hostedtoolcache/Python/3.14.6/x64
2026-08-01T02:37:14.0045120Z   Python3_ROOT_DIR: /opt/hostedtoolcache/Python/3.14.6/x64
2026-08-01T02:37:14.0045532Z   LD_LIBRARY_PATH: /opt/hostedtoolcache/Python/3.14.6/x64/lib
2026-08-01T02:37:14.0045847Z ##[endgroup]
2026-08-01T02:37:14.1430288Z Post job cleanup.
2026-08-01T02:37:14.3267327Z Post job cleanup.
2026-08-01T02:37:14.4354199Z [command]/usr/bin/git version
2026-08-01T02:37:14.4402710Z git version 2.54.0
2026-08-01T02:37:14.4478918Z Temporarily overriding HOME='/home/runner/work/_temp/194af022-769d-4644-8e68-a88a3e80b50f' before making global git config changes
2026-08-01T02:37:14.4482218Z Adding repository directory to the temporary git global config as a safe directory
2026-08-01T02:37:14.4492526Z [command]/usr/bin/git config --global --add safe.directory /home/runner/work/uv/uv
2026-08-01T02:37:14.6744652Z Removing SSH command configuration
2026-08-01T02:37:14.6745136Z [command]/usr/bin/git config --local --name-only --get-regexp core\.sshCommand
2026-08-01T02:37:14.6785107Z [command]/usr/bin/git submodule foreach --recursive sh -c "git config --local --name-only --get-regexp 'core\.sshCommand' && git config --local --unset-all 'core.sshCommand' || :"
2026-08-01T02:37:14.6985495Z Removing HTTP extra header
2026-08-01T02:37:14.6991441Z [command]/usr/bin/git config --local --name-only --get-regexp http\.https\:\/\/github\.com\/\.extraheader
2026-08-01T02:37:14.7032221Z [command]/usr/bin/git submodule foreach --recursive sh -c "git config --local --name-only --get-regexp 'http\.https\:\/\/github\.com\/\.extraheader' && git config --local --unset-all 'http.https://github.com/.extraheader' || :"
2026-08-01T02:37:14.7287216Z Removing includeIf entries pointing to credentials config files
2026-08-01T02:37:14.7294232Z [command]/usr/bin/git config --local --name-only --get-regexp ^includeIf\.gitdir:
2026-08-01T02:37:14.7327243Z [command]/usr/bin/git submodule foreach --recursive git config --local --show-origin --name-only --get-regexp remote.origin.url
2026-08-01T02:37:14.7707262Z Cleaning up orphan processes
